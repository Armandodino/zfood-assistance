import React, { useState, useRef } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ChatBubble } from "@/components/ChatBubble";
import { useTheme } from "@/hooks/useTheme";
import { useData } from "@/contexts/DataContext";
import { Spacing, BorderRadius, ZFoodColors, Shadows } from "@/constants/theme";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  language?: string;
}

const WELCOME_MESSAGE: Message = {
  id: "welcome",
  text: "Bonjour! Je suis l'assistant IA ZFood. Je peux vous aider avec la gestion de vos clients et commandes, répondre à vos questions en français et dans les langues locales ivoiriennes (Baoulé, Dioula, Bété, Sénoufo, Agni, Yacouba). Comment puis-je vous aider?",
  isUser: false,
};

export default function AIAssistantScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const { clients, orders, getTotalRevenue, getUnpaidTotal } = useData();
  const flatListRef = useRef<FlatList>(null);

  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const generateResponse = (userMessage: string): { text: string; language?: string } => {
    const lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.includes("combien") && lowerMessage.includes("client")) {
      return { text: `Vous avez actuellement ${clients.length} client(s) enregistré(s) dans votre carnet.` };
    }

    if (lowerMessage.includes("chiffre") || lowerMessage.includes("revenue") || lowerMessage.includes("vente")) {
      const revenue = getTotalRevenue();
      return { text: `Votre chiffre d'affaires total est de ${new Intl.NumberFormat("fr-FR").format(revenue)} FCFA.` };
    }

    if (lowerMessage.includes("impayé") || lowerMessage.includes("dette")) {
      const unpaid = getUnpaidTotal();
      return { text: `Le total des impayés s'élève à ${new Intl.NumberFormat("fr-FR").format(unpaid)} FCFA.` };
    }

    if (lowerMessage.includes("commande") && (lowerMessage.includes("combien") || lowerMessage.includes("total"))) {
      return { text: `Vous avez enregistré ${orders.length} commande(s) au total.` };
    }

    if (lowerMessage.includes("bonjour") || lowerMessage.includes("salut")) {
      return { text: "Bonjour! Comment puis-je vous aider aujourd'hui?" };
    }

    if (lowerMessage.includes("merci")) {
      return { text: "Je vous en prie! N'hésitez pas si vous avez d'autres questions." };
    }

    if (lowerMessage.includes("baoulé") || lowerMessage.includes("akwaba")) {
      return { text: "Akwaba! Mo ti mô klè? (Bienvenue! Comment ça va?)", language: "Baoulé" };
    }

    if (lowerMessage.includes("dioula") || lowerMessage.includes("aw ni sogoma")) {
      return { text: "Aw ni sogoma! I ka kènè wa? (Bonjour! Vous allez bien?)", language: "Dioula" };
    }

    const responses = [
      "Je peux vous aider avec la gestion de vos clients, commandes et statistiques. Posez-moi une question!",
      "Pour enregistrer une nouvelle commande, allez dans l'onglet Commandes et appuyez sur le bouton +.",
      "Vous pouvez voir les statistiques détaillées dans le Data Center.",
      "N'oubliez pas de vérifier vos impayés régulièrement pour maintenir une bonne trésorerie.",
    ];

    return { text: responses[Math.floor(Math.random() * responses.length)] };
  };

  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText.trim(),
      isUser: true,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputText("");
    setIsTyping(true);
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    setTimeout(() => {
      const response = generateResponse(userMessage.text);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text,
        isUser: false,
        language: response.language,
      };
      setMessages((prev) => [...prev, aiMessage]);
      setIsTyping(false);
    }, 800 + Math.random() * 700);
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: theme.backgroundDefault }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={(item) => item.id}
        inverted={messages.length > 0}
        contentContainerStyle={{
          paddingTop: Spacing.lg,
          paddingBottom: headerHeight + Spacing.lg,
          flexGrow: 1,
          justifyContent: "flex-end",
        }}
        renderItem={({ item, index }) => (
          <ChatBubble
            message={item.text}
            isUser={item.isUser}
            language={item.language}
            index={index}
          />
        )}
        ListHeaderComponent={
          isTyping ? (
            <View style={styles.typingContainer}>
              <View style={[styles.typingBubble, { backgroundColor: theme.backgroundSecondary }]}>
                <View style={styles.typingDots}>
                  <View style={[styles.dot, { backgroundColor: theme.textMuted }]} />
                  <View style={[styles.dot, { backgroundColor: theme.textMuted }]} />
                  <View style={[styles.dot, { backgroundColor: theme.textMuted }]} />
                </View>
              </View>
            </View>
          ) : null
        }
        onContentSizeChange={() => flatListRef.current?.scrollToOffset({ offset: 0, animated: true })}
      />

      <View style={[styles.inputContainer, { backgroundColor: theme.backgroundRoot, paddingBottom: insets.bottom + Spacing.sm }, Shadows.card]}>
        <TextInput
          style={[
            styles.input,
            { backgroundColor: theme.backgroundDefault, color: theme.text },
          ]}
          placeholder="Écrivez votre message..."
          placeholderTextColor={theme.textMuted}
          value={inputText}
          onChangeText={setInputText}
          multiline
          maxLength={500}
          onSubmitEditing={handleSend}
        />

        <Pressable
          style={[
            styles.sendButton,
            {
              backgroundColor: inputText.trim()
                ? ZFoodColors.primary600
                : theme.backgroundSecondary,
            },
          ]}
          onPress={handleSend}
          disabled={!inputText.trim()}
        >
          <Feather
            name="send"
            size={20}
            color={inputText.trim() ? "#fff" : theme.textMuted}
          />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    gap: Spacing.sm,
  },
  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 100,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    fontSize: 16,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  typingContainer: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
  },
  typingBubble: {
    alignSelf: "flex-start",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    marginLeft: 40,
  },
  typingDots: {
    flexDirection: "row",
    gap: 4,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    opacity: 0.5,
  },
});
