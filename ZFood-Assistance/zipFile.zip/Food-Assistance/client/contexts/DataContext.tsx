import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getApiUrl } from "@/lib/query-client";

export interface Client {
  id: string;
  name: string;
  quartier: string;
  phone: string;
  createdAt: string;
}

export interface Order {
  id: string;
  clientId: string;
  clientName: string;
  quantity: number;
  amount: number;
  isPaid: boolean;
  paidAt?: string;
  date: string;
  createdAt: string;
}

interface DataContextType {
  clients: Client[];
  orders: Order[];
  isLoading: boolean;
  addClient: (client: Omit<Client, "id" | "createdAt">) => Promise<void>;
  updateClient: (id: string, client: Partial<Client>) => Promise<void>;
  deleteClient: (id: string) => Promise<void>;
  addOrder: (order: Omit<Order, "id" | "createdAt">) => Promise<void>;
  updateOrder: (id: string, order: Partial<Order>) => Promise<void>;
  deleteOrder: (id: string) => Promise<void>;
  getClientOrders: (clientId: string) => Order[];
  getClientOrderCount: (clientId: string) => number;
  getTotalRevenue: () => number;
  getUnpaidTotal: () => number;
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const CLIENTS_KEY = "@zfood_clients";
const ORDERS_KEY = "@zfood_orders";

export function DataProvider({ children }: { children: ReactNode }) {
  const [clients, setClients] = useState<Client[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const [clientsData, ordersData] = await Promise.all([
        AsyncStorage.getItem(CLIENTS_KEY),
        AsyncStorage.getItem(ORDERS_KEY),
      ]);
      
      const parsedClients = clientsData ? JSON.parse(clientsData) : [];
      const parsedOrders = ordersData ? JSON.parse(ordersData) : [];
      
      setClients(parsedClients);
      setOrders(parsedOrders);
      
      // Sync to webapp on initial load
      if (parsedClients.length > 0 || parsedOrders.length > 0) {
        try {
          const url = new URL("/api/update-local", getApiUrl());
          await fetch(url.toString(), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ clients: parsedClients, orders: parsedOrders }),
          });
        } catch (e) {
          // Ignore webapp sync errors
        }
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const syncToWebapp = async (clientsData: Client[], ordersData: Order[]) => {
    try {
      const url = new URL("/api/update-local", getApiUrl());
      await fetch(url.toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clients: clientsData, orders: ordersData }),
      });
    } catch (error) {
      console.log("Webapp sync skipped:", error);
    }
  };

  const saveClients = async (newClients: Client[]) => {
    await AsyncStorage.setItem(CLIENTS_KEY, JSON.stringify(newClients));
    setClients(newClients);
    syncToWebapp(newClients, orders);
  };

  const saveOrders = async (newOrders: Order[]) => {
    await AsyncStorage.setItem(ORDERS_KEY, JSON.stringify(newOrders));
    setOrders(newOrders);
    syncToWebapp(clients, newOrders);
  };

  const addClient = useCallback(async (client: Omit<Client, "id" | "createdAt">) => {
    const newClient: Client = {
      ...client,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    await saveClients([...clients, newClient]);
  }, [clients]);

  const updateClient = useCallback(async (id: string, updates: Partial<Client>) => {
    const updated = clients.map((c) => (c.id === id ? { ...c, ...updates } : c));
    await saveClients(updated);
  }, [clients]);

  const deleteClient = useCallback(async (id: string) => {
    await saveClients(clients.filter((c) => c.id !== id));
  }, [clients]);

  const addOrder = useCallback(async (order: Omit<Order, "id" | "createdAt">) => {
    const newOrder: Order = {
      ...order,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    await saveOrders([...orders, newOrder]);
  }, [orders]);

  const updateOrder = useCallback(async (id: string, updates: Partial<Order>) => {
    const updated = orders.map((o) => {
      if (o.id === id) {
        const newOrder = { ...o, ...updates };
        if (updates.isPaid === true && !o.isPaid) {
          newOrder.paidAt = new Date().toISOString();
        }
        return newOrder;
      }
      return o;
    });
    await saveOrders(updated);
  }, [orders]);

  const deleteOrder = useCallback(async (id: string) => {
    await saveOrders(orders.filter((o) => o.id !== id));
  }, [orders]);

  const getClientOrders = useCallback((clientId: string) => {
    return orders.filter((o) => o.clientId === clientId).sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }, [orders]);

  const getClientOrderCount = useCallback((clientId: string) => {
    return orders.filter((o) => o.clientId === clientId).reduce((sum, o) => sum + (o.quantity || 1), 0);
  }, [orders]);

  const getTotalRevenue = useCallback(() => {
    return orders.filter((o) => o.isPaid).reduce((sum, o) => sum + o.amount, 0);
  }, [orders]);

  const getUnpaidTotal = useCallback(() => {
    return orders.filter((o) => !o.isPaid).reduce((sum, o) => sum + o.amount, 0);
  }, [orders]);

  const refreshData = useCallback(async () => {
    await loadData();
  }, [loadData]);

  return (
    <DataContext.Provider
      value={{
        clients,
        orders,
        isLoading,
        addClient,
        updateClient,
        deleteClient,
        addOrder,
        updateOrder,
        deleteOrder,
        getClientOrders,
        getClientOrderCount,
        getTotalRevenue,
        getUnpaidTotal,
        refreshData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
}
