import type { Express } from "express";
import { createServer, type Server } from "node:http";
import { syncDataToSheet } from "./google-sheets";
import path from "path";
import fs from "fs";

const ADMIN_PASSWORD = "ZFOOD";

// In-memory storage (synced with Google Sheets)
let clients: any[] = [];
let orders: any[] = [];

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve the WebApp dashboard
  app.get("/webapp", (_req, res) => {
    const webappPath = path.join(__dirname, "templates", "webapp.html");
    if (fs.existsSync(webappPath)) {
      res.sendFile(webappPath);
    } else {
      res.status(404).send("WebApp non disponible");
    }
  });

  // API: Get all clients
  app.get("/api/clients", (_req, res) => {
    res.json(clients);
  });

  // API: Add a new client
  app.post("/api/clients", (req, res) => {
    const { name, quartier, phone, password } = req.body;
    
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ error: "Mot de passe incorrect" });
    }
    
    if (!name || !quartier) {
      return res.status(400).json({ error: "Nom et quartier requis" });
    }
    
    const newClient = {
      id: generateId(),
      name,
      quartier,
      phone: phone || "",
      createdAt: new Date().toISOString()
    };
    
    clients.push(newClient);
    res.json(newClient);
  });

  // API: Get all orders
  app.get("/api/orders", (_req, res) => {
    res.json(orders);
  });

  // API: Add a new order
  app.post("/api/orders", (req, res) => {
    const { clientId, clientName, quantity, amount, isPaid, password } = req.body;
    
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ error: "Mot de passe incorrect" });
    }
    
    if (!clientId || !clientName) {
      return res.status(400).json({ error: "Client requis" });
    }
    
    const newOrder = {
      id: generateId(),
      clientId,
      clientName,
      quantity: quantity || 1,
      amount: amount || 5000,
      isPaid: isPaid || false,
      date: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };
    
    orders.push(newOrder);
    res.json(newOrder);
  });

  // API: Update order status
  app.patch("/api/orders/:id", (req, res) => {
    const { id } = req.params;
    const { isPaid, password } = req.body;
    
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ error: "Mot de passe incorrect" });
    }
    
    const order = orders.find(o => o.id === id);
    if (!order) {
      return res.status(404).json({ error: "Commande introuvable" });
    }
    
    order.isPaid = isPaid;
    if (isPaid) {
      order.paidAt = new Date().toISOString();
    }
    
    res.json(order);
  });

  // Sync data from mobile app and store locally
  app.post("/api/sync-sheets", async (req, res) => {
    try {
      const { clients: clientsData, orders: ordersData } = req.body;
      
      if (!clientsData || !ordersData) {
        return res.status(400).json({ 
          success: false, 
          message: "Données clients et commandes requises" 
        });
      }

      // Store data locally for webapp access
      clients = clientsData;
      orders = ordersData;

      const result = await syncDataToSheet(clientsData, ordersData);
      res.json(result);
    } catch (error: any) {
      console.error("Sync error:", error);
      res.status(500).json({ 
        success: false, 
        message: error.message || "Erreur lors de la synchronisation" 
      });
    }
  });

  // Update local data without syncing to sheets
  app.post("/api/update-local", (req, res) => {
    const { clients: clientsData, orders: ordersData } = req.body;
    
    if (clientsData) clients = clientsData;
    if (ordersData) orders = ordersData;
    
    res.json({ success: true, message: "Données mises à jour localement" });
  });

  app.get("/api/sync-status", async (_req, res) => {
    try {
      res.json({ 
        connected: true, 
        message: "Google Sheets connecté",
        clientCount: clients.length,
        orderCount: orders.length
      });
    } catch (error) {
      res.json({ 
        connected: false, 
        message: "Google Sheets non connecté" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 10);
}
