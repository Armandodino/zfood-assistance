import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const NOTIFICATION_PERMISSION_KEY = '@zfood_notification_permission';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS === 'web') {
    return false;
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  const granted = finalStatus === 'granted';
  await AsyncStorage.setItem(NOTIFICATION_PERMISSION_KEY, granted ? 'true' : 'false');
  
  return granted;
}

export async function checkNotificationPermission(): Promise<boolean> {
  if (Platform.OS === 'web') {
    return false;
  }
  
  const { status } = await Notifications.getPermissionsAsync();
  return status === 'granted';
}

export async function scheduleUnpaidReminder(
  clientName: string,
  amount: number,
  orderId: string,
  delayInHours: number = 24
): Promise<string | null> {
  const hasPermission = await checkNotificationPermission();
  
  if (!hasPermission) {
    const granted = await requestNotificationPermission();
    if (!granted) return null;
  }

  const identifier = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'Rappel de paiement',
      body: `${clientName} doit ${amount.toLocaleString()} FCFA`,
      data: { orderId, type: 'unpaid_reminder' },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
      seconds: delayInHours * 60 * 60,
    },
  });

  return identifier;
}

export async function scheduleImmediateNotification(
  title: string,
  body: string
): Promise<void> {
  const hasPermission = await checkNotificationPermission();
  
  if (!hasPermission) {
    await requestNotificationPermission();
  }

  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
    },
    trigger: null,
  });
}

export async function cancelNotification(identifier: string): Promise<void> {
  await Notifications.cancelScheduledNotificationAsync(identifier);
}

export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function getScheduledNotifications(): Promise<Notifications.NotificationRequest[]> {
  return await Notifications.getAllScheduledNotificationsAsync();
}
